var http = require('http');
var fs = require('fs');
var index = fs.readFileSync('index.html');

var SerialPort = require("serialport");
const path = require('path');

const folderpath = '/Users/alisonemilien/Project/ELG 4539 - Project/Website/assets'
var image1 = fs.readdirSync(folderpath);

const parsers = SerialPort.parsers;
const parser = new parsers.Readline({ delimiter: '\r\n' });

var port = new SerialPort('/dev/cu.usbserial-110', {
    baudRate: 115200,
    dataBits: 8,
    parity: 'none',
    stopBits: 1,
    flowControl: false
});

port.pipe(parser);

var app = http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(index);
});

var io = require('socket.io').listen(app);

io.on('connection', function (data) {
    console.log('Node is listening');
});
parser.on('data', function (data) {
    stringData = String(data);
    var splitData = stringData.split(",");
    console.log(splitData[0]);
    console.log(splitData[1]);
    console.log(splitData[2]);
    console.log(splitData[3]);
    io.emit('data', stringData);
});

app.listen(3000);

